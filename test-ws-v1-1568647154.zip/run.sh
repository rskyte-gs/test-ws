export DEVMODE=True
export SOCKETURL='http://192.168.10.42:9000'
python app.py